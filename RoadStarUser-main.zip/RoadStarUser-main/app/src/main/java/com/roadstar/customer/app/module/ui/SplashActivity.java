package com.roadstar.customer.app.module.ui;

import android.os.Bundle;
import android.os.Handler;

import com.roadstar.customer.app.data.preferences.PreferenceUtils;
import com.roadstar.customer.app.data.preferences.SharedPreferenceManager;
import com.roadstar.customer.app.module.ui.auth.WelcomeActivity;
import com.roadstar.customer.app.module.ui.main.MainActivity;
import com.roadstar.customer.common.base.BaseActivity;


public class SplashActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_splash);

    }

    @Override
    protected void onStart() {
        super.onStart();
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                checkLoginStatus();
            }
        }, 300);
    }

    void checkLoginStatus() {
        if (SharedPreferenceManager.getInstance().read(PreferenceUtils.IS_LOGGED_IN, false))
            gotoMainActivity();
        else
            gotoLandingActivity();

    }

    void gotoLandingActivity() {
        startActivityWithNoHistory(SplashActivity.this, WelcomeActivity.class);

    }

    void gotoMainActivity() {
        startActivityWithNoHistory(SplashActivity.this, MainActivity.class);

    }

}
