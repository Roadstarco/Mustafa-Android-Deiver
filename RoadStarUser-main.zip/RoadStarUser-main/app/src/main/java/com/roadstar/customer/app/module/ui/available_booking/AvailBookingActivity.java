package com.roadstar.customer.app.module.ui.available_booking;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

import com.roadstar.customer.R;
import com.roadstar.customer.app.module.ui.main.MainActivity;
import com.roadstar.customer.common.base.BaseActivity;

public class AvailBookingActivity extends BaseActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_avail_booking);
        init();
    }

    void init() {
        setActionBar(getString(R.string.available_booking));
        //  bindClicklisteners();
    }

    private void bindClicklisteners() {

        findViewById(R.id.btn_submit).setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {

        switch (view.getId()) {
            case R.id.btn_submit:
                startActivityWithNoHistory(this, MainActivity.class);
                break;


        }
    }
}