package com.roadstar.customer.common.utils;

final public class Configuration {

    public static final int HTTP_TIMEOUT = 10000; // milli seconds
    public static final String FLURRY_API_KEY = "";

    // region WEB_ADDRESS
    public static final String WEB_FAQ = "";
    public static final String WEB_HELP = "";
    //endregion

    // region WEB_API_CALLS
    public static final String API_LOGIN = "";
    //endregion
}