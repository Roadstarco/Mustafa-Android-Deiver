package com.roadstar.customer.app.module.ui.your_package;

import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.gson.Gson;
import com.roadstar.customer.R;
import com.roadstar.customer.R.id;
import com.roadstar.customer.app.data.UserManager;
import com.roadstar.customer.app.internationalDelivery.Model.AvailAbleTripsModel;
import com.roadstar.customer.app.internationalDelivery.classes.LockableBottomSheetBehavior;
import com.roadstar.customer.app.module.ui.your_package.model.AllBidsOnTripModel;
import com.roadstar.customer.app.network.ApiInterface;
import com.roadstar.customer.app.network.RetrofitClientInstance;
import com.transferwise.sequencelayout.SequenceStep;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Objects;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.roadstar.customer.app.module.ui.your_package.adapter.BidsOnTripAdapter.getSingle_item;
import static com.roadstar.customer.common.utils.ApiConstants.HEADER_BEARER;

public class DetailOfPackage extends AppCompatActivity implements View.OnClickListener {


    AppCompatImageView backBtn;
    AppCompatTextView title;
    public LinearLayout inProgress;
    AppCompatButton submitRating;
    private int trip_id = 0;

    private BottomSheetBehavior<ConstraintLayout> bottomSheetBehavior;
    public TextView name,type,size,provider_ID,src,des,riderName,riderNameTitle;
    private SequenceStep approved,arrived,pickedUp,started,Deliverd,rating,completed;
    private RatingBar rat05UserRating;
    private EditText edt05Comment;
    private ProgressBar progressBar;
    private ArrayList<AvailAbleTripsModel> available_trips = new ArrayList<>();
    private AvailAbleTripsModel availAbleTripsModel = new AvailAbleTripsModel();
    private Handler handler;
    private AllBidsOnTripModel acceptedItem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_of_package);

        initialze();
        getAllAvailable_trips();
        //setValues();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (handler != null){
            handler.removeCallbacks(null);
        }
    }

    private void getAllAvailable_trips() {


        /*Create handle for the RetrofitInstance interface*/
        ApiInterface service = RetrofitClientInstance.getRetrofitInstance().create(ApiInterface.class);
        Call<ArrayList<AvailAbleTripsModel>> call = service.getAllUserTrips(HEADER_BEARER + UserManager.getToken(), "XMLHttpRequest");
        call.enqueue(new Callback<ArrayList<AvailAbleTripsModel>>() {
            @Override
            public void onResponse(@NotNull Call<ArrayList<AvailAbleTripsModel>> call, @NotNull Response<ArrayList<AvailAbleTripsModel>> response) {
                available_trips =  response.body();
                if (available_trips != null && available_trips.size()>0) {
                    for (int i=0;i<available_trips.size();i++){
                        if (available_trips.get(i).getId() == trip_id){
                            checkAndSetPackageStatus(available_trips.get(i).getTrip_status(),available_trips.get(i).getUser_rated());
                            setValues(available_trips.get(i));
                            startHandler();
                            return;
                        }
                    }
                }

                Log.d("available_trips", new Gson().toJson(available_trips));

            }


            @Override
            public void onFailure(@NotNull Call<ArrayList<AvailAbleTripsModel>> call, @NotNull Throwable t) {
                Toast.makeText(DetailOfPackage.this, "Something went wrong...Please try later!", Toast.LENGTH_SHORT).show();
            }
        });
    }


    private void startHandler() {

        if (handler == null){
            handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    initialze();
                    getAllAvailable_trips();
                    handler.postDelayed(this, 3000);
                }
            }, 5000);
        }

    }

    private void setValues(AvailAbleTripsModel availAbleTripsModel) {

        if (availAbleTripsModel.getCreated_by().equals("user")){
            acceptedItem = getSingle_item(0);
            String riderNameString = acceptedItem.getFirst_name() + getString(R.string.space) + acceptedItem.getLast_name();
            riderName.setText(riderNameString);
        }else {
            riderNameTitle.setText(R.string.reciever_name);
            riderName.setText(availAbleTripsModel.getReceiver_name());
        }

        this.availAbleTripsModel = availAbleTripsModel;
        name.setText(availAbleTripsModel.getItem());

        if (availAbleTripsModel.getItem_type() == null){
            type.setText(availAbleTripsModel.getService_type());
        }else {
            type.setText(availAbleTripsModel.getItem_type());
        }

        type.setText(availAbleTripsModel.getService_type());
        size.setText(availAbleTripsModel.getItem_size());
        provider_ID.setText(String.valueOf(availAbleTripsModel.getProvider_id()));
        src.setText(availAbleTripsModel.getTripfrom());
        des.setText(availAbleTripsModel.getTripto());

    }

    private void initialze() {

        if (getIntent().hasExtra("pos")){
            int pos = getIntent().getIntExtra("pos", -1);
        }
        if (getIntent().hasExtra("trip_id")){
            trip_id = getIntent().getIntExtra("trip_id",-1);
        }
        setRatingLayout();

        progressBar = findViewById(R.id.progressBarRating);
        backBtn = findViewById(R.id.iv_back);
        title = findViewById(R.id.tv_title);

        submitRating = findViewById(R.id.btn_rate);
        name = findViewById(R.id.tv_packag_name);
        riderNameTitle = findViewById(id.textView3);
        riderName = findViewById(R.id.tv_rider_name);
        type = findViewById(R.id.tv_package_type);
        size = findViewById(R.id.tv_package_size);
        provider_ID = findViewById(R.id.tv_provider_ID);
        src = findViewById(R.id.tv_trip_start_dest);
        des = findViewById(R.id.tv_trip_end_dest);

        inProgress = findViewById(R.id.inProgressLayout);
        pickedUp =(SequenceStep)findViewById(R.id.pickedUp);
        approved =(SequenceStep)findViewById(R.id.approved);
        arrived =(SequenceStep)findViewById(R.id.arrived);
        started=(SequenceStep)findViewById(R.id.started);
        Deliverd =(SequenceStep)findViewById(R.id.deliverd);
        rating =(SequenceStep)findViewById(R.id.rating);
        completed = (SequenceStep)findViewById(R.id.completed);

        title.setText(R.string.status_activity_title);

        ConstraintLayout bottomSheet = findViewById(R.id.bottomSheet);
        bottomSheetBehavior = BottomSheetBehavior.from(bottomSheet);
        bottomSheetBehavior.setBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
            @Override
            public void onStateChanged(@NonNull View bottomSheet, int newState) {
                switch (newState) {
                    case BottomSheetBehavior.STATE_EXPANDED:
                        if (bottomSheetBehavior instanceof LockableBottomSheetBehavior) {
                            //noinspection rawtypes
                            ((LockableBottomSheetBehavior) bottomSheetBehavior).setLocked(true);
                        }
                    case BottomSheetBehavior.STATE_HIDDEN:
                        break;
                    case BottomSheetBehavior.STATE_COLLAPSED: {
                        inProgress.setVisibility(View.GONE);
                        bottomSheetBehavior.setState(BottomSheetBehavior.STATE_HIDDEN);
                    }
                    break;
                    case BottomSheetBehavior.STATE_DRAGGING:
                        break;
                    case BottomSheetBehavior.STATE_HALF_EXPANDED:
                        break;
                    case BottomSheetBehavior.STATE_SETTLING:
                        break;
                }
            }

            @Override
            public void onSlide(@NonNull View bottomSheet, float slideOffset) {

            }
        });

        bottomSheetBehavior.setState(BottomSheetBehavior.STATE_HIDDEN);


        backBtn.setOnClickListener(this);
        submitRating.setOnClickListener(this);
    }

    public void checkAndSetPackageStatus(String currentStatus, Integer user_rated) {

        try {
            switch (currentStatus) {

                case "STARTED":

                    removePrevious(approved);

                    started.setActive(true);
                    started.setSubtitle(R.string.current_status);
                    //programatically seting style to Title
                    started.setTitleTextAppearance(R.style.TextAppearance_AppCompat_Title);

                    break;

                case "ARRIVED":

                    removePrevious(started);

                    arrived.setActive(true);
                    arrived.setSubtitle(R.string.current_status);
                    //programatically seting style to Title
                    arrived.setTitleTextAppearance(R.style.TextAppearance_AppCompat_Title);

                    break;


                case "PICKEDUP":
                    removePrevious(arrived);
                    pickedUp.setActive(true);
                    pickedUp.setSubtitle(R.string.current_status);
                    //programatically seting style to Title
                    pickedUp.setTitleTextAppearance(R.style.TextAppearance_AppCompat_Title);

                    break;

                case "DROPPED":

                    removePrevious(pickedUp);

                    Deliverd.setActive(true);
                    Deliverd.setSubtitle(R.string.current_status);
                    //programatically seting style to Title
                    Deliverd.setTitleTextAppearance(R.style.TextAppearance_AppCompat_Title);

                    break;

                case "COMPLETED":


                    if (user_rated == 1){

                        removePrevious(rating);
                        completed.setActive(true);
                        completed.setSubtitle(R.string.current_status);
                        //programatically seting style to Title
                        completed.setTitleTextAppearance(R.style.TextAppearance_AppCompat_Title);

                    }else{

                        removePrevious(Deliverd);
                        rating.setActive(true);
                        rating.setSubtitle(R.string.current_status);
                        //programatically seting style to Title
                        rating.setTitleTextAppearance(R.style.TextAppearance_AppCompat_Title);

                        /*   rating.setOnClickListener(DetailOfPackage.this::onClick);
                         */

                        inProgress.setVisibility(View.VISIBLE);
                        bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
                    }


                    if (handler != null)
                        handler.removeCallbacks(null);
                    break;

                default:

                    approved.setActive(true);
                    approved.setSubtitle(R.string.current_status);
                    //programatically seting style to Title
                    approved.setTitleTextAppearance(R.style.TextAppearance_AppCompat_Title);
            }
        }catch (Exception e){
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }


    }

    private void removePrevious(SequenceStep previous) {
        try {

           /* previous.clearAnimation();
            previous.clearFocus();
            previous.setActive(false);*/

        }catch (Exception e){
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onBackPressed() {

        if (bottomSheetBehavior.getState() == BottomSheetBehavior.STATE_EXPANDED){
            bottomSheetBehavior.setState(BottomSheetBehavior.STATE_HIDDEN);
            inProgress.setVisibility(View.GONE);
        }else {

            super.onBackPressed();
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case id.iv_back:
                onBackPressed();
                break;
            case R.id.rating:
                inProgress.setVisibility(View.VISIBLE);
                bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
                break;

            case R.id.btn_rate:
                submitRatingRequest();
                break;
        }
    }

    private void setRatingLayout() {
        rat05UserRating = findViewById(R.id.rat05UserRating);
        edt05Comment = findViewById(R.id.edt05Comment);
    }

    private void submitRatingRequest() {
        progressBar.setVisibility(View.VISIBLE);
        SubmitRatingReq submitRatingReq = new SubmitRatingReq();
        submitRatingReq.setComment(edt05Comment.getText().toString());
        submitRatingReq.setRating((int) rat05UserRating.getRating());
        submitRatingReq.setTrip_id(this.availAbleTripsModel.getId().toString());

        ApiInterface mApiInterface = RetrofitClientInstance.getRetrofitInstance().create(ApiInterface.class);

        Call<ResponseBody> call = mApiInterface.submitRatingInternational(HEADER_BEARER + UserManager.getToken(), "XMLHttpRequest",submitRatingReq);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(@NonNull Call<ResponseBody> call, @NonNull retrofit2.Response<ResponseBody> response) {
                progressBar.setVisibility(View.GONE);
                if (response.isSuccessful() && response.body() != null) {
                    Toast.makeText(DetailOfPackage.this, "Trip completed", Toast.LENGTH_SHORT).show();
                    finish();
                }else
                    Toast.makeText(DetailOfPackage.this, "Trip not completed", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(@NonNull Call<ResponseBody> call, @NonNull Throwable t) {
                progressBar.setVisibility(View.GONE);
                Log.d("onFailure", Objects.requireNonNull(t.getMessage()));

            }

        });
    }
}