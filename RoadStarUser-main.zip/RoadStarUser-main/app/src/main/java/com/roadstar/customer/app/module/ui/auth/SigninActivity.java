package com.roadstar.customer.app.module.ui.auth;

import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;

import com.android.volley.AuthFailureError;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.gson.Gson;
import com.roadstar.customer.MyApplication;
import com.roadstar.customer.R;
import com.roadstar.customer.app.data.UserManager;
import com.roadstar.customer.app.data.models.card_model.CardDetails;
import com.roadstar.customer.app.module.ui.main.MainActivity;
import com.roadstar.customer.app.network.AppNetworkTask;
import com.roadstar.customer.app.network.HttpRequestItem;
import com.roadstar.customer.app.network.HttpResponseItem;
import com.roadstar.customer.common.base.BaseActivity;
import com.roadstar.customer.common.utils.AppUtils;
import com.roadstar.customer.common.utils.NetworkUtils;
import com.roadstar.customer.common.utils.Utilities;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static com.roadstar.customer.common.utils.ApiConstants.ANDROID;
import static com.roadstar.customer.common.utils.ApiConstants.BASE_URL;
import static com.roadstar.customer.common.utils.ApiConstants.CARD_PAYMENT_LIST;
import static com.roadstar.customer.common.utils.ApiConstants.CLIENT_SECRET;
import static com.roadstar.customer.common.utils.ApiConstants.GET_PROFILE_URL;
import static com.roadstar.customer.common.utils.ApiConstants.HEADER_BEARER;
import static com.roadstar.customer.common.utils.ApiConstants.KEY_CLIENT_ID;
import static com.roadstar.customer.common.utils.ApiConstants.KEY_CLIENT_SECRET;
import static com.roadstar.customer.common.utils.ApiConstants.KEY_DEVICE_ID;
import static com.roadstar.customer.common.utils.ApiConstants.KEY_DEVICE_TOKEN;
import static com.roadstar.customer.common.utils.ApiConstants.KEY_DEVICE_TYPE;
import static com.roadstar.customer.common.utils.ApiConstants.KEY_ERROR;
import static com.roadstar.customer.common.utils.ApiConstants.KEY_GRANT_TYPE;
import static com.roadstar.customer.common.utils.ApiConstants.KEY_PASSWORD;
import static com.roadstar.customer.common.utils.ApiConstants.KEY_SCOPE;
import static com.roadstar.customer.common.utils.ApiConstants.KEY_USER_NAME;
import static com.roadstar.customer.common.utils.ApiConstants.LOGIN_URL;

public class SigninActivity extends BaseActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signin);
        init();
    }

    void init() {
        setActionBar(getString(R.string.sign_in));
        bindClicklisteners();
    }

    private void bindClicklisteners() {
        findViewById(R.id.lay_reg_now).setOnClickListener(this);
        findViewById(R.id.btn_next).setOnClickListener(this);
        findViewById(R.id.tv_forget_pass).setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()) {
            case R.id.btn_next:
                if (isParamValid())
                    callLoginApi();
                break;
            case R.id.lay_reg_now:
                startActivity(this, PhoneNumbAuthActivity.class);
                break;
            case R.id.tv_forget_pass:
                startActivity(this, ForgetPasswordActivity.class);
                break;
        }
    }

    private boolean isParamValid() {
        boolean valid = true;
        if (!AppUtils.isEmailValid(findEditTextById(R.id.et_email).getText().toString())) //Check the User Name
        {
            findTextInputLayout(R.id.lay_email).setError(getString(R.string.error_invalid_email));
            valid = false;
            return valid;
        }
        findTextInputLayout(R.id.lay_email).setError(null);

        if (!AppUtils.isNotFieldEmpty(findEditTextById(R.id.et_password))) //Check the Password
        {
            findTextInputLayout(R.id.et_password).setError(getString(R.string.error_enter_pass));
            valid = false;
            return valid;
        }
        findTextInputLayout(R.id.lay_pass).setError(null);

        AppUtils.hideSoftKeyboard(this);//Hide keyboard
        return valid;
    }

    //Login
    private void callLoginApi() {
        showProgressDialog();
        HttpRequestItem requestItem = new HttpRequestItem(LOGIN_URL, "");
        requestItem.setHttpRequestType(NetworkUtils.HTTP_POST);
        requestItem.setParams(getRegParam());
        requestItem.setHeaderParams(AppUtils.getHeaderParams());
        AppNetworkTask appNetworkTask = new AppNetworkTask(getProgressDialog(false), this);
        appNetworkTask.execute(requestItem);
    }


    private Map<String, Object> getRegParam() {
        Map<String, Object> map = new HashMap<>();

        String token = "";
        if (FirebaseInstanceId.getInstance().getToken() != null)
            token = FirebaseInstanceId.getInstance().getToken();

        map.put(KEY_USER_NAME, AppUtils.getEditTextString(findEditTextById(R.id.et_email)));
        map.put(KEY_PASSWORD, AppUtils.getEditTextString(findEditTextById(R.id.et_password)));
        map.put(KEY_GRANT_TYPE, "password");
        map.put(KEY_CLIENT_ID, "2");
        map.put(KEY_CLIENT_SECRET, CLIENT_SECRET);
        map.put(KEY_SCOPE, "");
        map.put(KEY_DEVICE_ID, Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID));
        map.put(KEY_DEVICE_TOKEN, token);
        map.put(KEY_DEVICE_TYPE, ANDROID);
        Log.i("Fcm Token", token);
        Log.i("Device ID", Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID));
        return map;
    }

    JSONObject apiResponse;

    @Override
    public void onNetworkSuccess(HttpResponseItem response) {
        super.onNetworkSuccess(response);
        hideProgressDialog();
        try {

            apiResponse = new JSONObject(response.getResponse());
            if (response.getHttpRequestEndPoint().equals(LOGIN_URL)) {

                if (apiResponse.has(KEY_ERROR)) {
                    showSnackBar(apiResponse.getString("message"));

                } else {

                    UserManager.saveAccessToken(apiResponse);
                    callGetProfileApi();
                    // gotoMainActivity();
                }
            } else if (response.getHttpRequestEndPoint().equals(GET_PROFILE_URL)) {

                if (apiResponse.has(KEY_ERROR)) {
                    showSnackBar(apiResponse.getString("message"));

                } else {

                    gotoMainActivity();
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            hideProgressDialog();
        }
    }

    @Override
    public void onNetworkError(HttpResponseItem response) {
        super.onNetworkError(response);
        hideProgressDialog();
    }

    //Get Profile Api
    private void callGetProfileApi() {
        showProgressDialog();
       // String url_param = "?device_type=android&device_id=cb7e21f01dfd9ea2&device_token=cBS7Ax3UQYyUoqCqgS9AAA:APA91bFDZ8ymt6ZvEZIAZbZdbBYB7HsQJie4q08cvFXUm_2D3gIGMD24Y9SFdW-2tpxEwtwiKoqsZGBCHjB4FMh6jcmRTkIvpY7QAkFNTP5O6mjb1XjcyFjJNr6Ucn8AcacDXD7E3WCH";
        String url_param1 = "?device_type="+UserManager.getDeviceType()+
                "&device_id="+UserManager.getDeviceId(this)+
                "&device_token="+UserManager.getDeviceToken();
        HttpRequestItem requestItem = new HttpRequestItem(  GET_PROFILE_URL, url_param1);
        requestItem.setHttpRequestType(NetworkUtils.HTTP_GET);
       requestItem.setHeaderParams(AppUtils.getHeaderParams());
        AppNetworkTask appNetworkTask = new AppNetworkTask(getProgressDialog(false), this);
        appNetworkTask.execute(requestItem);
    }


    private Map<String, Object> getProfileParam() {
        Map<String, Object> map = new HashMap<>();
        String token = "";
        if (FirebaseInstanceId.getInstance().getToken() != null)
            token = FirebaseInstanceId.getInstance().getToken();
        map.put(KEY_DEVICE_TYPE, ANDROID);
        map.put(KEY_DEVICE_ID, Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID));
        map.put(KEY_DEVICE_TOKEN, token);
        return map;
    }


    void gotoMainActivity() {
        UserManager.saveUserData(apiResponse);
        UserManager.setIsUserLogin(true);
        //SharedPreferenceManager.getInstance().save(PreferenceUtils.IS_LOGGED_IN, true);
        //startActivityWithNoHistory(SigninActivity.this, MainActivity.class);

        checkCardInfo();
    }

    private ArrayList<JSONObject> getArrayListFromJSONArray(JSONArray jsonArray) {

        ArrayList<JSONObject> aList = new ArrayList<JSONObject>();

        try {
            if (jsonArray != null) {

                for (int i = 0; i < jsonArray.length(); i++) {

                    aList.add(jsonArray.getJSONObject(i));

                }

            }
        } catch (JSONException je) {
            je.printStackTrace();
        }

        return aList;

    }

    public void checkCardInfo() {

        Utilities utils = new Utilities();

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(BASE_URL + CARD_PAYMENT_LIST, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {

                utils.print("GetPaymentList", response.toString());
                if (response != null && response.length() > 0) {
                    ArrayList<JSONObject> listItems = getArrayListFromJSONArray(response);
                    if (listItems.isEmpty()) {
                        UserManager.setIsCardAdded(false);
                    }

                    for (JSONObject jsonObject : listItems) {
                        Gson gson = new Gson();
                        CardDetails card = gson.fromJson(jsonObject.toString(), CardDetails.class);

                        UserManager.setIsCardAdded(true);
                        UserManager.setCardID(card.getCard_id());

                        break;
                    }
                } else {

                    UserManager.setIsCardAdded(false);
                }

                startActivityWithNoHistory(SigninActivity.this, MainActivity.class);

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                UserManager.setIsCardAdded(false);
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> headers = new HashMap<String, String>();
                headers.put("X-Requested-With", "XMLHttpRequest");
                headers.put("Authorization", HEADER_BEARER + UserManager.getToken());
                return headers;
            }
        };

        MyApplication.getInstance().addToRequestQueue(jsonArrayRequest);
    }

}
