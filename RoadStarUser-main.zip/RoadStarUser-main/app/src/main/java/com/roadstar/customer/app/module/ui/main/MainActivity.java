package com.roadstar.customer.app.module.ui.main;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ScrollView;

import androidx.annotation.NonNull;
import androidx.core.view.GravityCompat;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.iid.FirebaseInstanceId;
import com.roadstar.customer.R;
import com.roadstar.customer.app.data.preferences.SharedPreferenceManager;
import com.roadstar.customer.app.internationalDelivery.InternationalMainActivity;
import com.roadstar.customer.app.module.ui.auth.WelcomeActivity;
import com.roadstar.customer.app.module.ui.available_booking.AvailBookingActivity;
import com.roadstar.customer.app.module.ui.booking_activity.BookingActivity;
import com.roadstar.customer.app.module.ui.booking_history.BookingHistoryActivity;
import com.roadstar.customer.app.module.ui.claim.ClaimActivity;
import com.roadstar.customer.app.module.ui.dialog.LogoutConfrmDialog;
import com.roadstar.customer.app.module.ui.payment_method.PaymentMethodActivity;
import com.roadstar.customer.app.module.ui.profile.MyProfileActivity;
import com.roadstar.customer.app.module.ui.support.SupportActivity;
import com.roadstar.customer.app.module.ui.your_package.YourPackageActivity;
import com.roadstar.customer.common.base.BaseActivity;

public class MainActivity extends BaseActivity implements View.OnClickListener, NavigationView.OnNavigationItemSelectedListener, LogoutConfrmDialog.OnInputListener {

    private int selectedItemId = 0;
    private boolean isItemSelected = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
        Log.d("Firebase", "token " + FirebaseInstanceId.getInstance().getToken());
    }

    @Override
    protected void onResume() {
        super.onResume();
        setHeaderData();
    }

    void init() {
        setActionBar(getString(R.string.road_star));
        populateDrawerView();
        setDrawerToggle();
        bindClickListners();


    }

    private void bindClickListners() {

        findViewById(R.id.tv_view_profile).setOnClickListener(MainActivity.this);
        findViewById(R.id.img_loc_delv).setOnClickListener(MainActivity.this);
        findViewById(R.id.img_intr_delv).setOnClickListener(MainActivity.this);
        findViewById(R.id.ll_home).setOnClickListener(MainActivity.this);
        findViewById(R.id.ll_post_trip).setOnClickListener(MainActivity.this);
        findViewById(R.id.ll_your_package).setOnClickListener(MainActivity.this);
        findViewById(R.id.ll_booking_history).setOnClickListener(MainActivity.this);
        findViewById(R.id.ll_available_booking).setOnClickListener(MainActivity.this);
        findViewById(R.id.ll_claim).setOnClickListener(MainActivity.this);
        findViewById(R.id.ll_payment_method).setOnClickListener(MainActivity.this);
        findViewById(R.id.ll_support).setOnClickListener(MainActivity.this);
        findViewById(R.id.ll_logout).setOnClickListener(MainActivity.this);

    }


    private void populateDrawerView() {
        mDrawerLayout = findViewById(R.id.layout_main);
        NavigationView mNavigationView = findViewById(R.id.nav_drawer_view);
        mNavigationView.setNavigationItemSelectedListener(this);
        mNavigationView.setItemIconTintList(null);
        mNavigationView.setCheckedItem(R.id.home);


    }


    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        // Sync the toggle state after onRestoreInstanceState has occurred.
        if (mDrawerToggle != null)
            mDrawerToggle.syncState();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (mDrawerToggle != null)
            mDrawerToggle.onConfigurationChanged(newConfig);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        NavigationView mNavigationView = (NavigationView) findViewById(R.id.nav_drawer_view);
        mNavigationView.setCheckedItem(item.getItemId());
        selectedItemId = item.getItemId();
        isItemSelected = true;
        mDrawerLayout.closeDrawers();
        return true;
    }

    @Override
    public void onDrawerClosed() {
        super.onDrawerClosed();
        if (!isItemSelected)
            return;
        isItemSelected = false;
        Class targetActivity = null;
        if (selectedItemId == R.id.tv_view_profile)
            targetActivity = MyProfileActivity.class;
        else if (selectedItemId == R.id.ll_home)
            closeDrawer();
        else if (selectedItemId == R.id.ll_your_package)
            targetActivity = YourPackageActivity.class;
        else if (selectedItemId == R.id.ll_post_trip)
            targetActivity = InternationalMainActivity.class;
        else if (selectedItemId == R.id.ll_booking_history)
            targetActivity = BookingHistoryActivity.class;
        else if (selectedItemId == R.id.ll_available_booking)
            targetActivity = AvailBookingActivity.class;
        else if (selectedItemId == R.id.ll_claim)
            targetActivity = ClaimActivity.class;
        else if (selectedItemId == R.id.ll_payment_method)
            targetActivity = PaymentMethodActivity.class;
        else if (selectedItemId == R.id.ll_support)
            targetActivity = SupportActivity.class;
        else if (selectedItemId == R.id.ll_logout)
            showLogoutDialog();


        ScrollView scrollView = findViewById(R.id.scroll_drawer);
        scrollView.scrollTo(0, 0);


        /*if (selectedItemId == R.id.ll_your_package && !UserManager.getRideInprogress()) {
            showToast("No booking in progress");
            return;
        } else */if (targetActivity != null) {
            startActivity(MainActivity.this, targetActivity);
        }

    }

    @Override
    public void onClick(View view) {
        selectedItemId = view.getId();

        if (selectedItemId == R.id.img_loc_delv ) {
            //if (UserManager.getRideInprogress()) {
                //showToast("Booking already in progress");
            //} else {
                startActivity(this, BookingActivity.class);
            //}

        }

        else if (selectedItemId == R.id.img_intr_delv) {
            startActivity(this, InternationalMainActivity.class);
        }

        else {
            isItemSelected = true;
            mDrawerLayout.closeDrawer(GravityCompat.START);
        }


    }

    void logoutApp() {
        SharedPreferenceManager.getInstance().clearPreferences();
        startActivity(new Intent(MainActivity.this, WelcomeActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK));
        finish();

    }

    @Override
    public void sendResponse(Boolean policyAccept) {

        if (policyAccept)
            logoutApp();
    }

    private void showLogoutDialog() {
        LogoutConfrmDialog logoutConfrmDialog = new LogoutConfrmDialog();
        logoutConfrmDialog.show(getSupportFragmentManager(), "LogoutConfrmDialog");
        logoutConfrmDialog.setCancelable(false);

    }

}
