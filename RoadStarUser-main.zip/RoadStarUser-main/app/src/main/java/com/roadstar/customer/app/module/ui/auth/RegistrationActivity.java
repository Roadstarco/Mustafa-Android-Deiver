package com.roadstar.customer.app.module.ui.auth;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.iid.FirebaseInstanceId;
import com.roadstar.customer.R;
import com.roadstar.customer.app.data.UserManager;
import com.roadstar.customer.app.data.models.LoginWithGoogleModel;
import com.roadstar.customer.app.data.preferences.PreferenceUtils;
import com.roadstar.customer.app.data.preferences.SharedPreferenceManager;
import com.roadstar.customer.app.module.ui.main.MainActivity;
import com.roadstar.customer.app.network.ApiInterface;
import com.roadstar.customer.app.network.AppNetworkTask;
import com.roadstar.customer.app.network.HttpRequestItem;
import com.roadstar.customer.app.network.HttpResponseItem;
import com.roadstar.customer.app.network.RetrofitClientInstance;
import com.roadstar.customer.common.utils.AppUtils;
import com.roadstar.customer.common.utils.FileUtils;
import com.roadstar.customer.common.utils.NetworkUtils;

import org.jetbrains.annotations.NotNull;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.roadstar.customer.common.utils.ApiConstants.ANDROID;
import static com.roadstar.customer.common.utils.ApiConstants.CLIENT_SECRET;
import static com.roadstar.customer.common.utils.ApiConstants.GRANT_PASSWORD;
import static com.roadstar.customer.common.utils.ApiConstants.HEADER_BEARER;
import static com.roadstar.customer.common.utils.ApiConstants.KEY_ADDRESS;
import static com.roadstar.customer.common.utils.ApiConstants.KEY_CLIENT_ID;
import static com.roadstar.customer.common.utils.ApiConstants.KEY_CLIENT_SECRET;
import static com.roadstar.customer.common.utils.ApiConstants.KEY_COUNTRY_NAME;
import static com.roadstar.customer.common.utils.ApiConstants.KEY_DEVICE_ID;
import static com.roadstar.customer.common.utils.ApiConstants.KEY_DEVICE_TOKEN;
import static com.roadstar.customer.common.utils.ApiConstants.KEY_DEVICE_TYPE;
import static com.roadstar.customer.common.utils.ApiConstants.KEY_EMAIL;
import static com.roadstar.customer.common.utils.ApiConstants.KEY_ERROR;
import static com.roadstar.customer.common.utils.ApiConstants.KEY_FIRST_NAME;
import static com.roadstar.customer.common.utils.ApiConstants.KEY_GRANT_TYPE;
import static com.roadstar.customer.common.utils.ApiConstants.KEY_LAST_NAME;
import static com.roadstar.customer.common.utils.ApiConstants.KEY_LOGIN_BY;
import static com.roadstar.customer.common.utils.ApiConstants.KEY_MOBILE;
import static com.roadstar.customer.common.utils.ApiConstants.KEY_PASSWORD;
import static com.roadstar.customer.common.utils.ApiConstants.KEY_PICTURE;
import static com.roadstar.customer.common.utils.ApiConstants.KEY_SOCIAL_UNIQUE_ID;
import static com.roadstar.customer.common.utils.ApiConstants.MANUAL;
import static com.roadstar.customer.common.utils.ApiConstants.PHONE;
import static com.roadstar.customer.common.utils.ApiConstants.SIGNUP_URL;

public class RegistrationActivity extends ProfileImageHandlingActivity implements View.OnClickListener {
    String phoneNumber = "";
    private GoogleSignInClient mGoogleSignInClient;
    private final int RC_SIGN_IN = 5050;
    private FirebaseAuth mAuth;
    private ProgressBar progressDoalog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        init();
    }

    void init() {
        // Initialize Firebase Auth
        mAuth = FirebaseAuth.getInstance();
        progressDoalog = findViewById(R.id.progressBar);
        setActionBar(getString(R.string.register));
        phoneNumber = getIntent().getStringExtra(PHONE);
        findViewById(R.id.img_google).setOnClickListener(this);
        findViewById(R.id.img_fb).setOnClickListener(this);
        bindClicklisteners();
    }

    private void bindClicklisteners() {
        findViewById(R.id.lay_signin).setOnClickListener(this);
        findViewById(R.id.btn_next).setOnClickListener(this);
        findViewById(R.id.iv_profile).setOnClickListener(this);

    }

    @Override
    public void onStart() {
        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        FirebaseUser currentUser = mAuth.getCurrentUser();
        //updateUI(currentUser);
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()) {
            case R.id.btn_next:
                if (isParamValid())
                    callSignupApi();
                break;
            case R.id.lay_signin:

                startActivityWithNoHistory(this, SigninActivity.class);
                break;
            case R.id.iv_profile:

                checkStoragePermission(R.id.iv_profile);
                break;
            case R.id.img_google:

                GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                        .requestIdToken("480273579736-nshbr92tqicl8jkvv2r3rmvast4nogjh.apps.googleusercontent.com")
                        .requestEmail()
                        .build();

                mGoogleSignInClient = GoogleSignIn.getClient(this, gso);

                GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(this);

                signIn();

                break;
            case R.id.img_fb:
                break;


        }
    }

    private void signIn() {
        Intent signInIntent = mGoogleSignInClient.getSignInIntent();
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Result returned from launching the Intent from GoogleSignInApi.getSignInIntent(...);
        if (requestCode == RC_SIGN_IN) {
            // Google Sign In was successful, authenticate with Firebase
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            handleSignInResult(task);
        }
    }

    private void handleSignInResult(Task<GoogleSignInAccount> completedTask) {
        try {
            GoogleSignInAccount account = completedTask.getResult(ApiException.class);

            callSignInWithGoogleApi(account.getIdToken());
        } catch (ApiException e) {
            // The ApiException status code indicates the detailed failure reason.
            // Please refer to the GoogleSignInStatusCodes class reference for more information.
            //Log.w(TAG, "signInResult:failed code=" + e.getStatusCode());
            //updateUI(null);
        }
    }

    private void callSignInWithGoogleApi(String accessToken) {
        progressDoalog.setVisibility(View.VISIBLE);

        String token = "";
        if (FirebaseInstanceId.getInstance().getToken() != null)
            token = FirebaseInstanceId.getInstance().getToken();
        String deviceId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);

        LoginWithGoogleModel loginWithGoogleModel = new LoginWithGoogleModel();
        loginWithGoogleModel.setDevice_type("android");
        loginWithGoogleModel.setDevice_token(token);
        loginWithGoogleModel.setAccessToken(accessToken);
        loginWithGoogleModel.setDevice_id(deviceId);
        loginWithGoogleModel.setLogin_by("google");
        loginWithGoogleModel.setMobile(phoneNumber);

        /*Create handle for the RetrofitInstance interface*/
        ApiInterface service = RetrofitClientInstance.getRetrofitInstance().create(ApiInterface.class);
        Call<LoginWithGoogleModel> call = service.loginWithGoogle(HEADER_BEARER + UserManager.getToken(), "XMLHttpRequest",loginWithGoogleModel);
        call.enqueue(new Callback<LoginWithGoogleModel>() {
            @Override
            public void onResponse(@NotNull Call<LoginWithGoogleModel> call, @NotNull Response<LoginWithGoogleModel> response) {
                progressDoalog.setVisibility(View.GONE);

                if (response.code() == 200){
                    getUserDetails(response.body().getAccessToken());
                }else
                    Toast.makeText(getApplicationContext(), R.string.something_went_wrong, Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onFailure(@NotNull Call<LoginWithGoogleModel> call, @NotNull Throwable t) {
                progressDoalog.setVisibility(View.GONE);
                Toast.makeText(getApplicationContext(), R.string.something_went_wrong, Toast.LENGTH_SHORT).show();
            }
        });
    }


    private void getUserDetails(String accessToken) {
        progressDoalog.setVisibility(View.VISIBLE);

        String token = "";
        if (FirebaseInstanceId.getInstance().getToken() != null)
            token = FirebaseInstanceId.getInstance().getToken();
        String deviceId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);

        LoginWithGoogleModel loginWithGoogleModel = new LoginWithGoogleModel();
        loginWithGoogleModel.setDevice_type("android");
        loginWithGoogleModel.setDevice_token(token);
        loginWithGoogleModel.setDevice_id(deviceId);

        /*Create handle for the RetrofitInstance interface*/
        ApiInterface service = RetrofitClientInstance.getRetrofitInstance().create(ApiInterface.class);
        Call<JSONObject> call = service.getUserDetails(HEADER_BEARER + accessToken, loginWithGoogleModel);
        call.enqueue(new Callback<JSONObject>() {
            @Override
            public void onResponse(@NotNull Call<JSONObject> call, @NotNull Response<JSONObject> response) {
                progressDoalog.setVisibility(View.GONE);

                if (response.code() == 200){

                    gotoMainActivity(response.body());

                }else
                    Toast.makeText(getApplicationContext(), R.string.something_went_wrong, Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onFailure(@NotNull Call<JSONObject> call, @NotNull Throwable t) {
                progressDoalog.setVisibility(View.GONE);
                Toast.makeText(getApplicationContext(), R.string.something_went_wrong, Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void GoToBeginActivity(){
        Intent mainIntent = new Intent(getApplicationContext(), MainActivity.class);
        mainIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(mainIntent);
        finish();
    }

    public void displayMessage(String toastString) {
        Snackbar.make(getCurrentFocus(), toastString, Snackbar.LENGTH_SHORT)
                .setAction("Action", null).show();
        // Toast.makeText(context, ""+toastString, Toast.LENGTH_SHORT).show();
    }
    private boolean isParamValid() {
        boolean valid = true;
        if (!AppUtils.isNotFieldEmpty(findEditTextById(R.id.et_f_name))) //Check the First Name
        {
            findTextInputLayout(R.id.input_lay_f_name).setError(getString(R.string.error_field_empty));
            valid = false;
            return valid;
        }
        findTextInputLayout(R.id.input_lay_f_name).setError(null);
        if (!AppUtils.isNotFieldEmpty(findEditTextById(R.id.et_l_name))) //Check the Last Name
        {
            findTextInputLayout(R.id.input_lay_l_name).setError(getString(R.string.error_field_empty));
            valid = false;
            return valid;
        }
        findTextInputLayout(R.id.input_lay_l_name).setError(null);
        if (!AppUtils.isNotFieldEmpty(findEditTextById(R.id.et_email))) //Check the Email
        {
            findTextInputLayout(R.id.lay_email).setError(getString(R.string.error_field_empty));
            valid = false;
            return valid;
        }
        findTextInputLayout(R.id.lay_email).setError(null);

        if (!AppUtils.isNotFieldEmpty(findEditTextById(R.id.et_country))) //Check the country
        {
            findTextInputLayout(R.id.input_lay_country).setError(getString(R.string.error_field_empty));
            valid = false;
            return valid;
        }
        findTextInputLayout(R.id.input_lay_country).setError(null);

        if (!AppUtils.isNotFieldEmpty(findEditTextById(R.id.et_address))) //Check the address
        {
            findTextInputLayout(R.id.input_lay_address).setError(getString(R.string.error_field_empty));
            valid = false;
            return valid;
        }
        findTextInputLayout(R.id.input_lay_address).setError(null);


        if (!AppUtils.isNotFieldEmpty(findEditTextById(R.id.et_password))) //Check the Password
        {
            findTextInputLayout(R.id.et_password).setError(getString(R.string.error_enter_pass));
            valid = false;
            return valid;
        }
        findTextInputLayout(R.id.input_lay_pass).setError(null);

        AppUtils.hideSoftKeyboard(this);//Hide keyboard
        return valid;
    }

    //Signup
    private void callSignupApi() {
        showProgressDialog();
        HttpRequestItem requestItem = new HttpRequestItem(SIGNUP_URL, "");
        //  HttpRequestItem requestItem = new HttpRequestItem( "https://emernox.com/api/user/signup");
        requestItem.setHttpRequestType(NetworkUtils.HTTP_POST);
        requestItem.setParams(getRegParam());
        requestItem.setHeaderParams(AppUtils.getHeaderParams());
        AppNetworkTask appNetworkTask = new AppNetworkTask(getProgressDialog(false), this);
        appNetworkTask.execute(requestItem);
    }


    private Map<String, Object> getRegParam() {
        Map<String, Object> map = new HashMap<>();

        String token = "";
        if (FirebaseInstanceId.getInstance().getToken() != null)
            token = FirebaseInstanceId.getInstance().getToken();
        String deviceId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);

        map.put(KEY_LOGIN_BY, MANUAL);
        map.put(KEY_FIRST_NAME, AppUtils.getEditTextString(findEditTextById(R.id.et_f_name)));
        map.put(KEY_LAST_NAME, AppUtils.getEditTextString(findEditTextById(R.id.et_l_name)));
        map.put(KEY_MOBILE, phoneNumber);
        String path = FileUtils.getPath(RegistrationActivity.this, Uri.parse(findVizImageView(R.id.iv_profile).getImageURL()));
        map.put(KEY_PICTURE, "");
        map.put(KEY_SOCIAL_UNIQUE_ID, "");
        map.put(KEY_EMAIL, AppUtils.getEditTextString(findEditTextById(R.id.et_email)));
        map.put(KEY_GRANT_TYPE, GRANT_PASSWORD);
        map.put(KEY_CLIENT_ID, 2);
        map.put(KEY_CLIENT_SECRET, CLIENT_SECRET);
        map.put(KEY_PASSWORD, AppUtils.getEditTextString(findEditTextById(R.id.et_password)));
        map.put(KEY_DEVICE_TYPE, ANDROID);
        map.put(KEY_DEVICE_ID, deviceId);
        map.put(KEY_DEVICE_TOKEN, token);
        map.put(KEY_ADDRESS, AppUtils.getEditTextString(findEditTextById(R.id.et_address)));
        map.put(KEY_COUNTRY_NAME, AppUtils.getEditTextString(findEditTextById(R.id.et_country)));
//Address and country missing
        Log.i("Fcm Token", token);
        Log.i("Device ID", Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID));
        return map;
    }

    JSONObject apiResponse;

    @Override
    public void onNetworkSuccess(HttpResponseItem response) {
        super.onNetworkSuccess(response);
        hideProgressDialog();
        try {

            apiResponse = new JSONObject(response.getResponse());
            if (response.getHttpRequestEndPoint().equals(SIGNUP_URL)) {

                if (apiResponse.has(KEY_ERROR)) {
                    showSnackBar("The email has already been taken.");

                } else {
                    gotoMainActivity(null);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            showSnackBar(getString(R.string.something_wrong));
        }
    }

    @Override
    public void onNetworkError(HttpResponseItem response) {
        super.onNetworkError(response);
        hideProgressDialog();
        showSnackBar("Email already exists");
    }

    void gotoMainActivity(JSONObject res) {
        if (res != null){

            UserManager.saveAccessToken(res);
            UserManager.saveUserData(res);
        }else {

            UserManager.saveAccessToken(apiResponse);
            UserManager.saveUserData(apiResponse);
        }

        SharedPreferenceManager.getInstance().save(PreferenceUtils.IS_LOGGED_IN, true);
        startActivityWithNoHistory(RegistrationActivity.this, MainActivity.class);
    }
}