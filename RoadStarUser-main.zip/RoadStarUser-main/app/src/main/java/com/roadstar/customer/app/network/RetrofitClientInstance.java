package com.roadstar.customer.app.network;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static com.roadstar.customer.common.utils.ApiConstants.BASE_URL;

public class RetrofitClientInstance {
    private static Retrofit retrofit;


    public static Retrofit getRetrofitInstance() {
        if (retrofit == null) {
            retrofit = new Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        return retrofit;
    }

//    public static Retrofit getClientForStringResponse() {
//
//        if (retrofit == null) {
//            retrofit=  new Retrofit.Builder()
//                    .addConverterFactory(ScalarsConverterFactory.create())
//                    .baseUrl(BASE_URL)
//                    .build();
//        }
//        return retrofit;
//    }

    public static Retrofit getLiveTrackingClient() {
        if (retrofit == null) {
            retrofit = new Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .build();
        }
        return retrofit;
    }

}
